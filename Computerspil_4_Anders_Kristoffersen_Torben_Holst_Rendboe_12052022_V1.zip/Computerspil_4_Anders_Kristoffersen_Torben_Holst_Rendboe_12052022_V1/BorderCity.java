
/**
 * The class BorderCity 
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-05-11 (CG3-1) - Aproved
 */
public class BorderCity extends City
{
    /**
     * The constructor passes parameters to the super class City
     * @param name      The city name
     * @param value     The value of the city
     * @param country   The country of the city
     */
    public BorderCity(String name, int value, Country country){
        super(name, value, country); 
    }
    
    /**
     * The metod handles a player's arrival to a border city to collect a bonus and pay toll.
     * @param p   A player
     */
    @Override // extends City
    public int arrive (Player p) { 
        int bonus = super.arrive();
        int toll = 0;
        if( ! p.getFromCountry().equals(getCountry())) {  // super not necesary
            toll = ( (p.getMoney() * getCountry().getGame().getSettings().getTollToBePaid() ) / 100 ); 
            changeValue(toll); 
        }
        return bonus - toll;
    }
}
