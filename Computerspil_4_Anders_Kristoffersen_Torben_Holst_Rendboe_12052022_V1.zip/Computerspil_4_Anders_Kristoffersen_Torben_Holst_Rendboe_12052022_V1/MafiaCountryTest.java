
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Set;
import java.util.HashSet;

/**
 * The classe MafiaCountryTest.
 *
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-05-11 (CG3-3) - The testserver didn't approve the class, but the instructor did. :-)
 */
public class MafiaCountryTest
{
    private Game game;
    private Country country1, country2;
    private City cityC, cityD, cityE, cityF, cityG;

    /**
     * Default constructor for test class MafiaCountryTest
     */
    public MafiaCountryTest() {
    }

    /**
     * Sets up the test fixture before every test case method.
     */
    @BeforeEach
    public void setUp() {
        // Create game object
        game = new Game(0); 

        // Create countries
        country1 = new Country("Country 1");
        country1.setGame(game);

        country2 = new MafiaCountry("Country 2");
        country2.setGame(game);

        // Create cities
        cityC = new BorderCity("City C", 40, country1);     // Border
        cityD = new CapitalCity("City D", 100, country1);   // Capital

        cityE = new CapitalCity("City E", 50, country2);    // Capital
        cityF = new BorderCity("City F", 90, country2);     // Border
        cityG = new City("City G", 70, country2);

        // Connect cities to countries
        country1.addCity(cityC);
        country1.addCity(cityD);

        country2.addCity(cityE);
        country2.addCity(cityF);
        country2.addCity(cityG);

        // Create roads
        country1.addRoads(cityC, cityD, 2);
        country1.addRoads(cityC, cityE, 4);
        country1.addRoads(cityD, cityF, 3);

        country2.addRoads(cityE, cityC, 4);
        country2.addRoads(cityE, cityF, 2);
        country2.addRoads(cityE, cityG, 5);
        country2.addRoads(cityF, cityD, 3);
        country2.addRoads(cityF, cityG, 6);
    }

    @Test
    public void constructor() {
        assertEquals("Country 2", country2.getName());
        assertEquals(3, country2.getCities().size());
    }

    /**
     * The method tests that 
     *    - the number of robberries is about 20_000 (20 % out of 100_000 or (risk / 100) * 100000)
     *    - the loss is about 30 (greater than 28 and lesser than 32)
     *    - the number of different whole number losses is 41 (and alternatively that bonus attains the values 10 through 50)
     *    - the bonus is calculated correctly when no robbery has occured
     *    - Capitals with and without border crossing  (independent of the optional toll setting)
     *    - Border cities with and without border crossing
     *    - the special cases (where the bonus is 1 or 0) are well behaved
     *    
     * The testserver doesn't approve the method. Therefore we have tried different things to see if we
     * there was some odd case we had forgotten to test for. Therefore there may be a bit more code than 
     * necesary below line 122.
     */
    @Test
    public void bonus() {
        int risk = country2.getGame().getSettings().getRisk();
        for(int seed = 0; seed <= 1000; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();
            Set<Integer> losses = new HashSet<>();
            int sumOfBonuses = 0;
            int robs = 0;
            int loss = 0; // sumOfLosses
            for(int k = 0; k < 100000; k++){
                int bonus = country2.bonus(cityE.getValue());
                if(bonus < 0) {
                    assertTrue(-50 <= bonus && bonus <= -10);
                    robs++;
                    loss -= bonus; 
                    losses.add(-bonus);
                }
                else {
                    assertTrue(0 <= bonus && bonus <= cityE.getValue()); 
                    bonuses.add(bonus);
                    sumOfBonuses += bonus;
                }
            }
            int expectedSum = cityE.getInitialValue() * (100000 - robs) / 2;  
            assertTrue(expectedSum * 0.99 < sumOfBonuses && sumOfBonuses < expectedSum * 1.01); // 39600 < sumOfBonuses < 40400
            assertEquals(51, bonuses.size());                                // cityE.getInitialValue() + 1 = 51
            int avarageLoss = loss / robs;
            assertTrue(100000 * risk / 100 * 0.95 < robs && robs < 100000 * risk / 100 * 1.05);  // 19000 < robs < 21000 iff risk == 20
            assertTrue(30 * 0.95 < avarageLoss && avarageLoss < 30 * 1.05);  // 28 < avarageLoss < 32
            assertEquals(41, losses.size()); // or

            // Since the testserver won't approve MafiaCountryTest we try the following cases:
            // Testing crossing a border with no robberies going to the capital (E)
            Player player = new GUIPlayer(new Position(cityC, cityE, 0), 100);
            game.getRandom().setSeed(seed);          // Set seed
            int bonus = country2.bonus(50);          // cityE.getInitialValue() = 50
            int toll = country2.getGame().getSettings().getTollToBePaid();  // toll == 20                         // 100 * 20 %
            int expense = game.getRandom().nextInt(100 + bonus - toll + 1);
            if(bonus >= 0) {
                game.getRandom().setSeed(seed);      // Same seed as above
                assertEquals(bonus - toll - expense, cityE.arrive(player));
                assertEquals(50 - bonus + toll + expense, cityE.getValue()); 
                cityE.reset();
            }
            // Testing with no robberies and not crossing a border going to the capital (E)
            player = new GUIPlayer(new Position(cityF, cityE, 0), 100);  // Same country
            game.getRandom().setSeed(seed);          // Set seed 
            bonus = country2.bonus(50);              // cityE.getInitialValue() = 50
            expense = game.getRandom().nextInt(100 + bonus + 1);
            if(bonus >= 0) {
                game.getRandom().setSeed(seed);      // Same seed as above
                assertEquals(bonus - expense, cityE.arrive(player));
                assertEquals(50 + expense - bonus, cityE.getValue()); 
                cityE.reset(); 
            }
            // Testing crossing a border with no robberies going to a border city (F)
            player = new GUIPlayer(new Position(cityD, cityF, 0), 100);
            game.getRandom().setSeed(seed);      // Set seed
            bonus = country2.bonus(90);          // cityF.getInitialValue() = 90
            if(bonus >= 0) {
                game.getRandom().setSeed(seed);      // Same seed as above
                assertEquals(bonus - toll, cityF.arrive(player));
                assertEquals(90 - bonus + toll, cityF.getValue()); 
                cityF.reset();
            }
            //Testing with no robberies and not crossing a border going to a border city (F)
            player = new GUIPlayer(new Position(cityG, cityF, 0), 100);  // Same country
            game.getRandom().setSeed(seed);                              // Set seed 
            bonus = country2.bonus(90);                                  // cityE.getInitialValue() = 90
            if(bonus >= 0) {
                game.getRandom().setSeed(seed);      // Same seed as above
                assertEquals(bonus, cityF.arrive(player));
                assertEquals(90 - bonus, cityF.getValue()); 
                cityF.reset(); 
            }
        }
        // bonus(1):
        for(int seed = 0; seed <= 100; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();
            Set<Integer> losses = new HashSet<>();
            int sumOfBonuses = 0;
            int robs = 0;
            int loss = 0;
            for(int k = 0; k < 100000; k++){
                int bonus = country2.bonus(1);
                if(bonus < 0) {
                    assertTrue(-50 <= bonus && bonus <= -10);
                    robs++;
                    loss -= bonus; 
                    losses.add(-bonus);
                }
                else {
                    assertTrue(0 <= bonus && bonus <= 1);
                    bonuses.add(bonus);
                    sumOfBonuses += bonus;
                }
            }
            int expectedSum = (100000 - robs) / 2; 
            assertTrue(expectedSum * 0.95 <= sumOfBonuses && sumOfBonuses <= expectedSum * 1.05);
            assertEquals(2, bonuses.size());
            int avarageLoss = loss / robs;
            assertTrue(100000 * risk / 100 * 0.95 < robs && robs < 100000 * risk / 100 * 1.05);
            assertTrue(30 * 0.95<= avarageLoss && avarageLoss <= 30 * 1.05);
            assertEquals(41, losses.size()); 
        }
        // bonus(0):           
        for(int seed = 0; seed <= 100; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();
            Set<Integer> losses = new HashSet<>();
            int sumOfBonuses = 0;
            int robs = 0;
            int loss = 0;
            for(int k = 0; k < 100000; k++){
                int bonus = country2.bonus(0);
                if(bonus < 0) {
                    assertTrue(-50 <= bonus && bonus <= -10);
                    robs++    ;
                    loss -= bonus; 
                    losses.add(-bonus);
                }
                else {
                    assertEquals(0, bonus);
                    bonuses.add(bonus);
                    sumOfBonuses += bonus;
                }
            }
            int expectedSum = 0;
            assertEquals(0, sumOfBonuses);
            assertEquals(1, bonuses.size());
            int avarageLoss = loss / robs;
            assertTrue(100000 * risk / 100 * 0.95 < robs && robs < 100000 * risk / 100 * 1.05);
            assertTrue(30 * 0.95 <= avarageLoss && avarageLoss <= 30 * 1.05);
            assertEquals(41, losses.size());
        }
    }

    /**
     * River test-fixture ned.
     *
     * Kaldt efter hver testmetode.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
