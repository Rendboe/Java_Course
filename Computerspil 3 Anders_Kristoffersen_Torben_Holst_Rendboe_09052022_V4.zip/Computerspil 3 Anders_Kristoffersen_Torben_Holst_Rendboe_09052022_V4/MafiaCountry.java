
/**
 * Lav en beskrivelse af klassen MafiaCountry her.
 * 
 * @author (dit navn her)
 * @version (versions nummer eller dato her)
 */
public class MafiaCountry extends Country
{
    /**
     * Creates a MafiaCountry object with a specified name.
     * @param name      The name of the country.
     */
    public MafiaCountry(String name){   // 
        super(name); 
    }
    
    @Override
    public int bonus(int value) {
        int risk = getGame().getSettings().getRisk();
        int lost = getGame().getLoss();
        if(getGame().getRandom().nextInt(99) < risk) {
            return -lost;
        }
        return super.bonus(value);
    }
}
