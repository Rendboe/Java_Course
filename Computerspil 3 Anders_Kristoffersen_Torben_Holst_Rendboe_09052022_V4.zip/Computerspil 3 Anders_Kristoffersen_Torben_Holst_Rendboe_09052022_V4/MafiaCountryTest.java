
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Set;
import java.util.HashSet;

/**
 * Testklassen MafiaCountryTest.
 *
 * @author (dit navn her)
 * @version (versionsnummer eller dato her)
 */
public class MafiaCountryTest
{
    private Game game;
    private Country country1, country2;
    private City cityA, cityB, cityC, cityD, cityE, cityF, cityG;

    /**
     * Standardkonstruktør for testklassen MafiaCountryTest
     */
    public MafiaCountryTest()
    {
    }

    /**
     * Opsæt test-fixtures.
     *
     * Kaldt før hver testmetode.
     */
    @BeforeEach
    public void setUp()
    {
        // Create game object
        game = new Game(0);

        // Create countries
        country1 = new Country("Country 1");
        country1.setGame(game);

        country2 = new MafiaCountry("Country 2");
        country2.setGame(game);

        // Create cities
        cityA = new City("City A", 80, country1);
        cityB = new City("City B", 60, country1);
        cityC = new City("City C", 40, country1);
        cityD = new City("City D", 100, country1);
        cityE = new City("City E", 50, country2);
        cityF = new City("City F", 90, country2);
        cityG = new City("City G", 70, country2);

        // Connect cities to countries
        country1.addCity(cityA);
        country1.addCity(cityB);
        country1.addCity(cityC);
        country1.addCity(cityD);

        country2.addCity(cityE);
        country2.addCity(cityF);
        country2.addCity(cityG);

        // Create roads
        country1.addRoads(cityA, cityB, 4);
        country1.addRoads(cityA, cityC, 3);
        country1.addRoads(cityA, cityD, 5);
        country1.addRoads(cityB, cityD, 2);
        country1.addRoads(cityC, cityD, 2);
        country1.addRoads(cityC, cityE, 4);
        country1.addRoads(cityD, cityF, 3);
        country2.addRoads(cityE, cityC, 4);
        country2.addRoads(cityE, cityF, 2);
        country2.addRoads(cityE, cityG, 5);
        country2.addRoads(cityF, cityD, 3);
        country2.addRoads(cityF, cityG, 6);
    }

    @Test
    public void bonus() {        
        for(int seed = 0; seed <= 1000; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();                                                                                 // HashSet til registrering af bonus
            Set<Integer> bonusesLost = new HashSet<>();                                                                             // HashSet til registrering af Lost
            int sumOfBonuses = 0;                                                                                                   // bonus sum
            int nuOfNegativBonuses = 0;                                                                                             // antal lost
            int bonusLostSum = 0;                                                                                                   // lost sum
            for(int k = 0; k < 100000; k++){
                int bonus = country2.bonus(cityE.getValue());                                                                                     // hent bonus fra city E
                if(bonus < 0) {                                                                                                     // hvis bonus er negativ
                    nuOfNegativBonuses += 1;                                                                                        // tæl antal negativ op
                    assertTrue(-50 <= bonus && bonus <= -10);                                                                       // er lost mellem -10 & -50 -------------------------------------------------------------------------------- Lost tjek
                    bonusLostSum -= bonus;                                                                                          // læg lost til sum af lost
                    bonusesLost.add(-bonus);                                                                                        // læg lost i HashSet
                }
                else {
                    assertTrue(0 <= bonus && bonus <= cityE.getValue());                                                                          // tjek om bonus er mellem 0 og city E value --------------------------------------------------------------- bonus tjek
                    bonuses.add(bonus);                                                                                             // læg bonus i HashSet
                    sumOfBonuses += bonus;                                                                                          // læg bonus til bonus sum
                }
            }
            int expectedSum = cityE.getValue() * (100000-nuOfNegativBonuses) / 2;                                                   // beregn den forventede sum (((100000 - antal lost) * city Es value) / 2) .... city E er 50
            assertTrue(expectedSum * 0.9 <= sumOfBonuses && sumOfBonuses <= expectedSum * 1.1);                                     // tjekker om summen af bonus er forventet +/- 10 % -------------------------------------------------------- bonus tjek
            assertEquals(cityE.getValue() + 1, bonuses.size());                                                                     // tjekker om bonus Set er mellem 0 og city E value (50) --------------------------------------------------- bonus tjek
            int averageLost = bonusLostSum / nuOfNegativBonuses;                                                                    // beregner gennemsnits lost (total lost / anatl lost)
            assertTrue(100000*0.2*0.9 <= nuOfNegativBonuses && nuOfNegativBonuses <= 100000*0.2*1.1);                               // antal lost mellem 20 % 100000 +/- 10 % ------------------------------------------------------------------ Lost tjek
            assertTrue(30 * 0.9 <= averageLost && averageLost <= 30 * 1.1);                                                         // gennemsnits lost = 30 +/- 10 % -------------------------------------------------------------------------- Lost tjek
            assertEquals(41, bonusesLost.size());                                                                                   // Lost Set mængde = 41 [10, 50] --------------------------------------------------------------------------- Lost tjek
        }
        // bonus(1):
        for(int seed = 0; seed <= 1000; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();
            Set<Integer> bonusesLost = new HashSet<>();
            int sumOfBonuses = 0;
            int nuOfNegativBonuses = 0;
            int bonusLostSum = 0;
            for(int k = 0; k < 100000; k++){
                int bonus = country2.bonus(1);
                if(bonus < 0) {
                    nuOfNegativBonuses += 1;
                    assertTrue(-50 <= bonus && bonus <= -10);                                                                       // er lost mellem -10 & -50 -------------------------------------------------------------------------------- Lost tjek
                    bonusLostSum -= bonus; 
                    bonusesLost.add(-bonus);
                }
                else {
                    assertTrue(0 <= bonus && bonus <= 1);
                    bonuses.add(bonus);
                    sumOfBonuses += bonus;
                }
            }
            int expectedSum = (100000-nuOfNegativBonuses) / 2;     // By multiplying before division we avoid loss of digits
            assertTrue(expectedSum * 0.9 <= sumOfBonuses && sumOfBonuses <= expectedSum * 1.1);
            assertEquals(2, bonuses.size());
            int averageLost = bonusLostSum / nuOfNegativBonuses;
            assertTrue(100000*0.2*0.9 <= nuOfNegativBonuses && nuOfNegativBonuses <= 100000*0.2*1.1);
            assertTrue(30 * 0.9 <= averageLost && averageLost <= 30 * 1.1);
            assertEquals(41, bonusesLost.size());
        }
        // bonus(0)
        for(int seed = 0; seed <= 1000; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonusesLost = new HashSet<>();
            int nuOfNegativBonuses = 0;
            int bonusLostSum = 0;
            for(int k = 0; k < 100000; k++){
                int bonus = country2.bonus(0);
                if(bonus < 0) {
                    nuOfNegativBonuses += 1;
                    assertTrue(-50 <= bonus && bonus <= -10);                                                                       // er lost mellem -10 & -50 -------------------------------------------------------------------------------- Lost tjek
                    bonusLostSum -= bonus; 
                    bonusesLost.add(-bonus);
                } else
                {
                    assertTrue(0 == bonus);
                }
            }
            int averageLost = bonusLostSum / nuOfNegativBonuses;
            assertTrue(100000*0.2*0.9 <= nuOfNegativBonuses && nuOfNegativBonuses <= 100000*0.2*1.1);
            assertTrue(30 * 0.9 <= averageLost && averageLost <= 30 * 1.1);
            assertEquals(41, bonusesLost.size());
        }
    }

    /**
     * River test-fixture ned.
     *
     * Kaldt efter hver testmetode.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
