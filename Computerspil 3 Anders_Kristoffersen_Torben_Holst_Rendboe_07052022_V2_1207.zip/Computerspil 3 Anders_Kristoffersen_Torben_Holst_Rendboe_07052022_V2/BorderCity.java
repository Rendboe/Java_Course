
/**
 * The class BorderCity models a SubClass to city (in the computergame assignment).
 * 
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-04-22 ("CG3 - Opgave 1")
 */
public class BorderCity extends City
{
        /**
     * Creates a new City object. 
     * The constructor of City objects passes the parameters to the field variables.
     * @param name    The name of the city
     * @param value   The value of the city
     */
    public BorderCity(String name, int value, Country country){
        super(name, value, country);
    }
    
    @Override
    public int arrive(Player p) {
        int bonus = super.arrive();
        if(!super.getCountry().equals(p.getFromCountry())){
            int tax = getCountry().getGame().getSettings().getTollToBePaid()*p.getMoney()/100;
            super.changeValue(tax);
            return bonus - tax;
        }
        return bonus;
    }
}