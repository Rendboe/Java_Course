
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Set;
import java.util.HashSet;

/**
 * Testklassen MafiaCountryTest.
 *
 * @author (dit navn her)
 * @version (versionsnummer eller dato her)
 */
public class MafiaCountryTest
{
    private Game game;
    private Country country1, country2;
    private City cityA, cityB, cityC, cityD, cityE, cityF, cityG;

    /**
     * Standardkonstruktør for testklassen MafiaCountryTest
     */
    public MafiaCountryTest()
    {
    }

    /**
     * Opsæt test-fixtures.
     *
     * Kaldt før hver testmetode.
     */
    @BeforeEach
    public void setUp()
    {
        // Create countries
        country1 = new Country("Country 1");
        country2 = new MafiaCountry("Country 2");

        // Create cities
        cityA = new City("City A", 80, country1);
        cityB = new City("City B", 60, country1);
        cityC = new City("City C", 40, country1);
        cityD = new City("City D", 100, country1);
        cityE = new City("City E", 50, country2);
        cityF = new City("City F", 90, country2);
        cityG = new City("City G", 70, country2);

        // Connect cities to countries
        country1.addCity(cityA);
        country1.addCity(cityB);
        country1.addCity(cityC);
        country1.addCity(cityD);

        country2.addCity(cityE);
        country2.addCity(cityF);
        country2.addCity(cityG);

        // Create roads
        country1.addRoads(cityA, cityB, 4);
        country1.addRoads(cityA, cityC, 3);
        country1.addRoads(cityA, cityD, 5);
        country1.addRoads(cityB, cityD, 2);
        country1.addRoads(cityC, cityD, 2);
        country1.addRoads(cityC, cityE, 4);
        country1.addRoads(cityD, cityF, 3);
        country2.addRoads(cityE, cityC, 4);
        country2.addRoads(cityE, cityF, 2);
        country2.addRoads(cityE, cityG, 5);
        country2.addRoads(cityF, cityD, 3);
        country2.addRoads(cityF, cityG, 6);
    }
    
    @Test
    public void bonus() {
        for(int seed = 0; seed <= 100; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();
            int sumOfBonuses = 0;
            for(int k = 0; k < 100000; k++){
                int bonus = country1.bonus(cityA.getValue());
                assertTrue(0 <= bonus && bonus <= cityA.getValue());
                bonuses.add(bonus);
                sumOfBonuses += bonus;
            }
            int expectedSum = cityA.getInitialValue() * 100000 / 2;     // By multiplying before division we avoid loss of digits
            assertTrue(expectedSum * 0.99 <= sumOfBonuses && sumOfBonuses <= expectedSum * 1.01);
            assertEquals(cityA.getInitialValue() + 1, bonuses.size());
        }
        // bonus(1):
        for(int seed = 0; seed <= 100; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();
            int sumOfBonuses = 0;
            for(int k = 0; k < 100000; k++){
                int bonus = country1.bonus(1);
                assertTrue(0 <= bonus && bonus <= 1);
                bonuses.add(bonus);
                sumOfBonuses += bonus;
            }
            int expectedSum =  100000 / 2; 
            assertTrue(expectedSum * 0.99 <= sumOfBonuses && sumOfBonuses <= expectedSum * 1.01);
            assertEquals(2, bonuses.size());
        }
        // assertTrue(0 == country1.bonus(1) || 1 == country1.bonus(1));
        assertTrue(0 == country1.bonus(0));
    }

    /**
     * River test-fixture ned.
     *
     * Kaldt efter hver testmetode.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
