
/**
 * The class CapitalCity models a SubClass to city (in the computergame assignment).
 * 
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-04-22 ("CG3 - Opgave 2")
 */
public class CapitalCity extends BorderCity
{
        /**
     * Creates a new City object. 
     * The constructor of City objects passes the parameters to the field variables.
     * @param name    The name of the city
     * @param value   The value of the city
     */
    public CapitalCity(String name, int value, Country country){
        super(name, value, country);
    }
    
    @Override
    public int arrive(Player p) {
        int bonus = super.arrive(p);
        int money = p.getMoney();
        int expenses = getCountry().getGame().getRandom().nextInt(money+bonus+1);
        super.changeValue(expenses);
        return bonus - expenses;
    }
}
