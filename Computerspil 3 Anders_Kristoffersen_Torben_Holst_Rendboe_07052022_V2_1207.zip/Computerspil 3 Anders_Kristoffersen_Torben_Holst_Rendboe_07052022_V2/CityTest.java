
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class CityTest.
 *
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-04-30 ("CG2 - Opgave 3") - Aproved by the test server
 */
public class CityTest
{
    private Game game;
    private Country country1, country2;
    private City cityA, cityE;

    /**
     * Default constructor for test class CityTest
     */
    public CityTest() {

    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp() {   // Kopi fra CGTest - husk cleanup
        // Create countries 
        country1 = new Country("Country 1");
        country2 = new Country("Country 2");

        // Create game object (for generation of random objects)
        game = new Game(0);
        country1.setGame(game);
        country2.setGame(game);

        // Create cities
        cityA = new City("City A", 80, country1);
        cityE = new City("City E", 50, country2);

        // Connect cities to countries
        country1.addCity(cityA);
        country2.addCity(cityE);
    }

    @Test
    public void constructor() {
        assertEquals("City A", cityA.getName());
        assertEquals(80, cityA.getValue());
        assertEquals(80, cityA.getInitialValue());
        assertEquals(country1, cityA.getCountry());

        assertEquals("City E", cityE.getName());
        assertEquals(50, cityE.getValue());
        assertEquals(50, cityE.getInitialValue());
        assertEquals(country2, cityE.getCountry());
    }

    // We don't have to test: getName, getValue, getInitialValue, getCountry.

    @Test
    public void changeValue(){
        cityA.changeValue(20);
        assertEquals(100, cityA.getValue());
        cityE.changeValue(-50);
        assertEquals(0, cityE.getValue());
        cityE.changeValue(-50);             // This situation may not occur in a game
        assertEquals(-50, cityE.getValue());  
    }

    @Test
    public void reset(){  
        cityA.changeValue(20);          // To test reset() we need a change first
        cityA.reset();
        assertEquals(80, cityA.getValue());
    }

    @Test
    public void testToString(){
        assertEquals("City A (80)", cityA.toString());
        cityE.changeValue(-50);
        assertEquals("City E (0)", cityE.toString());
    }

    // We don't have to test: compareTo, equals, hashCode.

    @Test
    public void arrive(){
        // City A
        for(int seed = 0; seed < 1000; seed++) {     // Try out different seeds
            game.getRandom().setSeed(seed);          // Set seed
            int bonus = country1.bonus(80);          // Remember bonus
            game.getRandom().setSeed(seed);          // Reset seed
            assertEquals(bonus, cityA.arrive());     // Same bonus
            assertEquals(80-bonus, cityA.getValue());// value has been reduced by the same amount
            cityA.reset();                           // Get ready to test with a new seed
        }
        cityA.changeValue(-80);                      // The value of City A is now zero
        assertEquals(0, cityA.getValue());
        assertEquals(0, cityA.arrive());             // Correction: assert return value of arrive
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown() {
    }
}
