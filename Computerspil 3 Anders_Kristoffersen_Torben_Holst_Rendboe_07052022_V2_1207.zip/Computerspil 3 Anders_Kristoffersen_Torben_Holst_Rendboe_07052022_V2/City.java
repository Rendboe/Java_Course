
/**
 * The class City models a city (in the computergame assignment).
 * 
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-04-15 ("CG1 - Opgave 1, 5 og 7")
 */
public class City implements Comparable<City> //Assignment 1 + 5
{
    private String name;
    private int value, initialValue;
    protected Country country;

    /**
     * Creates a new City object. 
     * The constructor of City objects passes the parameters to the field variables.
     * @param name    The name of the city
     * @param value   The value of the city
     */
    public City(String name, int value, Country country){
        this.name = name;
        this.value = value;
        this.initialValue = value;
        this.country = country;
    }

    /**
     * The method gets the name of the city.
     * @return      The name of the city
     */
    public String getName(){
        return name;
    }

    /**
     * The method gets the value of the city.
     * @return      The value of the city
     */
    public int getValue(){
        return value;
    }

    /**
     * The method gets the initial value of the city.
     * @return      The initial value of the city
     */
    public int getInitialValue(){
        return initialValue;
    }

    /**
     * The method gets the country object of the city.
     * @return      The country object of the city
     */
    public Country getCountry(){
        return country;
    }

    /**
     * Adds amount to the city's value. 
     * @param amount  The amount to add to the city's value.
     */
    public void changeValue(int amount){
        value += amount;
    }

    /**
     * Resets the city's value to the initial value.
     */
    public void reset(){
        value = initialValue;
    }

    /**
     * Returns a string consisting of the name followed the value in brackets.
     * Thus defineing the formating when printing name and value to the terminal.
     */
    @Override 
    public String toString(){
        return name + " (" + value + ")";
    }

    /**
     * Defines how to sort cities (alphabeticaly). 
     * It is a part of the implementation of Comparable<>.
     * @param that   The other city to compare to.
     */
    public int compareTo(City that){
        return name.compareTo(that.name); // Assending sort: that - this > 0 => that > this
    }
  
    /**
     * Defines an equivalence relation of City objects. 
     * @return 'true' if two City objects have the same name and 'false' otherwise.
     */
    @Override 
    public boolean equals(Object city) {  //I mplementation acording to lecture notes "Slides-Uge11.pdf" p. 36.
        if(city == this) {
            return true;
        }
        if(city == null) {
            return false;
        }
        if(city.getClass() != getClass()) {
            return false;
        }
        City that = (City) city;
        return name.equals(that.name) && country.equals(that.country);
    }

    /**
     * Generates a hashcode based on the initial value and the name of the city. We have chosen to stick to
     * the traditonal prime 31.
     * @return  The hashcode of the City object.
     */
    @Override
    public int hashCode() { //Implementation acording to lecture notes "Slides-Uge11.pdf" p. 30.
        // int result = country.hashCode();
        // for( int i = 0; i < name.length(); i++) {
        //     result = 31 * result + name.charAt(i);
        // }
        // return result;
        return 29 * country.hashCode() + 31 * name.hashCode();
    }

    /**
     * The method reduces the value of the City object by the same amount as the
     * bonus obtained by the player.
     */
    public int arrive(){    // Opgave 7
        int bonus = country.bonus(value);
        value -= bonus;  // Reduce the value of the city by the same ammount
        return bonus;
    }
    
    public int arrive (Player p) { 
        return arrive(); 
    }
}
