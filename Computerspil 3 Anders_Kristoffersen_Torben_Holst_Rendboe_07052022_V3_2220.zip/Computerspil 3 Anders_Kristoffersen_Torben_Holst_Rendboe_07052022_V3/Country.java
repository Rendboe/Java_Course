import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
// import java.util.Random;
import java.util.stream.*;      // getCity() and reset()
import java.util.*;
import java.util.Optional;      // getCity()

/**
 * The class Country models a country of the computergame.
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-04-15 ("opgave 4, 7 og 9")
 */
public class Country
{
    private String name;
    private Map<City, Set<Road>> network;
    private Game game;

    /**
     * Creates a Country object with a specified name.
     * @param name      The name of the country.
     */
    public Country(String name){   // Opgave 4
        this.name = name;
        network = new TreeMap<>();
    }

    /**
     * The method returns the Country's name.
     * @return   The name of the country.
     */
    public String getName(){    // Opgave 4
        return name;
    }

    /**
     * The method returns the Country's cities as a set.
     * @return   The set of cities of the country.
     */
    public Set<City> getCities() {    // Opgave 4
        return network.keySet();
    }

    /**
     * The method returns the city with the given name.
     * @param name   The name of a city.
     * @return       A City object with the given name.
     */
    public City getCity(String name) {    // Opgave 4
        // Slides-Uge5-Torsdag.pdf, p. 20
        return network.keySet().stream()
        .filter(e -> e.getName().equals(name))
        .findFirst().orElse(null);
    }

    /**
     * The method returns the set of roads of the city.
     * @param c   A City .
     * @return   The roads of runing from a given city.
     */
    public Set<Road> getRoads(City c) {    // Opgave 4
        return network.getOrDefault(c, new TreeSet<>());
    }

    /**
     * Returns the current game.
     * @return   The current game
     */
    public Game getGame(){   // Opgave 7
        return game;
    }

    /**
     * The method sets the game to a new Game.
     * @param game  The new game
     */
    public void setGame(Game game){  // Opgave 7
        this.game = game;
    }

    /**
     * Resets all cities values to the initial values.
     */
    public void reset() {   // Opgave 4
        network.keySet().stream().forEach(c -> c.reset());  
    }

    /**
     * @return  The name of the country (actually repeating the method getName() )
     */
    @Override
    public String toString(){
        return name;
    }

    /**
     * Defines an equivalence relation of Country objects. 
     * @param country   A Country
     * @return   'true' if two Country objects have the same name and 'false' otherwise.
     */
    @Override // Implementation acording to lecture notes "Slides-Uge11.pdf" p. 36.
    public boolean equals(Object country) {
        if(country == this) {
            return true;
        }
        if(country == null) {
            return false;
        }
        if(country.getClass() != getClass()) {
            return false;
        }
        Country that = (Country) country;
        return name.equals(that.name);
    }

    /**
     * Generates a hashcode based on the initial value and the name of the city. We have chosen to stick to
     * the traditonal prime 31.
     * @return  The hashcode of the City object.
     */
    @Override
    public int hashCode() { // Implementation acording to lecture notes "Slides-Uge11.pdf" p. 30?
        return 29 * name.hashCode() + 31 * name.hashCode();
    }

    /**
     * The bonus received by the player is calculated randomly.
     * @param value   The maximum  amount available in the city.
     * @return        The bonus to be passed to the player or deducted from the city.
     */
    public int bonus(int value){  // Opgave 5 og 7
        if(value > 0){
            // A random whole number in the interval [0,value] including the end points.
            return game.getRandom().nextInt(value+1);  
        }
        return 0;
    }

    /**
     * The method adds a City object to the country. 
     * The method does not check that the city belongs to the country (but this is accepted by the testserver).
     * @param c   A City
     */
    public void addCity(City c){  // Opgave 6
        network.put(c,new TreeSet<>());
    }

    /**
     * If one of the given cities belongs to the country this method adds a road to the city set of roads and 
     * if both of the given cities belong to the country this method adds a road to both cities' set of roads.
     * @param a         A city where the road starts or stops
     * @param b         A city where the road starts or stops
     * @param length    The length of the road
     */
    public void addRoads(City a, City b, int length){   // Opgave 6
        if(!a.equals(b) && length > 0){
            if(a.getCountry().getName().equals(name) && network.containsKey(a)){
                Road rdA = new Road(a, b, length);
                network.get(a).add(rdA);       // Get the city's roads from network and add the new road
            }

            if(b.getCountry().getName().equals(name) && network.containsKey(b)){
                Road rdB = new Road(b, a, length);
                network.get(b).add(rdB);
            }
        }
    }

    /**
     * Overloading...
     * @param city   A City
     */
    public Position position(City city) {    // Opgave 6
        return new Position(city, city, 0);
    }

    /**
     * The method creats a start position of a player going from a city to a city. 
     * (The length of the road equals the distance left.)
     * @param from   The City the player travelse from
     * @param to     The City the player travelse to
     */
    public Position readyToTravel(City from, City to){    // Opgave 6
        // "Find one" algorithm template
        if(from.equals(to)){        // In case the cities aren't different. 
            return position(from); 
        }
        for(Road r : getRoads(from)) {
            if(r.getTo().equals(to)){
                return new Position(from, to, r.getLength());  
            }
        }
        return position(from); // In case no direct connection excists
    }
}
