
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Set;
import java.util.HashSet;

/**
 * Testklassen MafiaCountryTest.
 *
 * @author (dit navn her)
 * @version (versionsnummer eller dato her)
 */
public class MafiaCountryTest
{
    private Game game;
    private Country country1, country2;
    private City cityA, cityB, cityC, cityD, cityE, cityF, cityG;

    /**
     * Standardkonstruktør for testklassen MafiaCountryTest
     */
    public MafiaCountryTest()
    {
    }

    /**
     * Opsæt test-fixtures.
     *
     * Kaldt før hver testmetode.
     */
    @BeforeEach
    public void setUp()
    {
        // Create game object
        game = new Game(0);
        
        // Create countries
        country1 = new Country("Country 1");
        country1.setGame(game);
        
        country2 = new MafiaCountry("Country 2");
        country2.setGame(game);

        // Create cities
        cityA = new City("City A", 80, country1);
        cityB = new City("City B", 60, country1);
        cityC = new City("City C", 40, country1);
        cityD = new City("City D", 100, country1);
        cityE = new City("City E", 50, country2);
        cityF = new City("City F", 90, country2);
        cityG = new City("City G", 70, country2);

        // Connect cities to countries
        country1.addCity(cityA);
        country1.addCity(cityB);
        country1.addCity(cityC);
        country1.addCity(cityD);

        country2.addCity(cityE);
        country2.addCity(cityF);
        country2.addCity(cityG);

        // Create roads
        country1.addRoads(cityA, cityB, 4);
        country1.addRoads(cityA, cityC, 3);
        country1.addRoads(cityA, cityD, 5);
        country1.addRoads(cityB, cityD, 2);
        country1.addRoads(cityC, cityD, 2);
        country1.addRoads(cityC, cityE, 4);
        country1.addRoads(cityD, cityF, 3);
        country2.addRoads(cityE, cityC, 4);
        country2.addRoads(cityE, cityF, 2);
        country2.addRoads(cityE, cityG, 5);
        country2.addRoads(cityF, cityD, 3);
        country2.addRoads(cityF, cityG, 6);
    }
    
    @Test
    public void bonus() {        
        for(int seed = 0; seed <= 100; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();
            Set<Integer> bonusesLost = new HashSet<>();
            int sumOfBonuses = 0;
            int nuOfNegativBonuses = 0;
            int bonusLostSum = 0;
            for(int k = 0; k < 100000; k++){
                int bonus = country2.bonus(cityE.getValue());
                if(bonus < 0) {
                    nuOfNegativBonuses += 1;
                    bonusLostSum += -bonus; 
                    bonusesLost.add(-bonus);
                }
                else {
                    assertTrue(0 <= bonus && bonus <= cityE.getValue());
                    bonuses.add(bonus);
                    sumOfBonuses += bonus;
                    }
            }
            int expectedSum = cityE.getInitialValue() * (100000-nuOfNegativBonuses) / 2;     // By multiplying before division we avoid loss of digits
            assertTrue(expectedSum * 0.9 <= sumOfBonuses && sumOfBonuses <= expectedSum * 1.1);
            assertEquals(cityE.getInitialValue() + 1, bonuses.size());
            int averageLost = bonusLostSum / nuOfNegativBonuses;
            assertTrue(20000*0.9 <= nuOfNegativBonuses && nuOfNegativBonuses <= 20000*1.1);
            assertTrue(30 * 0.9 <= averageLost && averageLost <= 30 * 1.1);
            assertEquals(41, bonusesLost.size());
            assertTrue(bonusesLost.contains(10) && bonusesLost.contains(50));
        }
        // bonus(1):
        for(int seed = 0; seed <= 100; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();
            Set<Integer> bonusesLost = new HashSet<>();
            int sumOfBonuses = 0;
            int nuOfNegativBonuses = 0;
            int bonusLostSum = 0;
            for(int k = 0; k < 100000; k++){
                int bonus = country2.bonus(1);
                if(bonus < 0) {
                    nuOfNegativBonuses += 1;
                    bonusLostSum += -bonus; 
                    bonusesLost.add(-bonus);
                }
                else {
                    assertTrue(0 <= bonus && bonus <= 1);
                    bonuses.add(bonus);
                    sumOfBonuses += bonus;
                    }
            }
            int expectedSum = (100000-nuOfNegativBonuses) / 2;     // By multiplying before division we avoid loss of digits
            assertTrue(expectedSum * 0.9 <= sumOfBonuses && sumOfBonuses <= expectedSum * 1.1);
            assertEquals(2, bonuses.size());
            int averageLost = bonusLostSum / nuOfNegativBonuses;
            assertTrue(20000*0.9 <= nuOfNegativBonuses && nuOfNegativBonuses <= 20000*1.1);
            assertTrue(30 * 0.9 <= averageLost && averageLost <= 30 * 1.1);
            assertEquals(41, bonusesLost.size());
            assertTrue(bonusesLost.contains(10) && bonusesLost.contains(50));
        }
        // assertTrue(0 == country1.bonus(1) || 1 == country1.bonus(1));
        assertTrue(0 == country2.bonus(0));
    }

    /**
     * River test-fixture ned.
     *
     * Kaldt efter hver testmetode.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
