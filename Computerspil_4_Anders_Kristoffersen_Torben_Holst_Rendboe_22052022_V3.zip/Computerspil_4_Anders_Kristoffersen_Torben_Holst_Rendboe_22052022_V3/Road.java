
/**
 * The class Road models a road between two cities.
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-04-15 ("opgave 2")
 */
public class Road implements Comparable<Road> 
{
    private City from, to;
    private int length;

    /**
     * Creates a Road object between two cities of a given length.
     * @param from      The beginging of the road
     * @param to        The ending of the road
     * @param length    How long the road is in km(?).
     */
    public Road(City from, City to, int length){
        this.from = from;
        this.to = to;
        this.length = length;
    }

    /**
     * Gets the 'form' City object.
     * returns   the road's form City object 
     */
    public City getFrom(){
        return from;
    }

    /**
     * Gets the 'to' City object.
     * returns the road's to City object 
     */
    public City getTo(){
        return to;
    }

    /**
     * Gets the lenght of the road.
     * returns the length of road 
     */
    public int getLength(){
        return length;
    }

    /**
     * Returns a string consisting of the names and values of the endpoint cities and 
     * the length of the actual road. The string if formatted for printing like this:
     * “London (60) -> Liverpool (40) : 8”.
     */
    @Override
    public String toString(){
        return from.toString() + " -> " + to.toString() + " : " + length;       
    }

    /**
     * Defines how to sort Roads objects. The sorting order is 
     *   primarily by from city, 
     *   secondarily by to city, and 
     *   finally by lenght of the road.
     */
    public int compareTo(Road that){
        if(from.equals(that.from) && to.equals(that.to)) {
            return length - that.length; 
        }
        if(from.equals(that.from)) {
            return to.compareTo(that.to);
        }
        return from.compareTo(that.from);
    }

    /**
     * Defines an equivalence relation of Road objects. 
     * @return 'true' if two Road objects have the same to, from, and length and 'false' otherwise.
     */
    @Override 
    public boolean equals(Object road) { //I mplementation acording to lecture notes "Slides-Uge11.pdf" p. 36.
        if(road == this) {
            return true;
        }
        if(road == null) {
            return false; 
        }
        if(road.getClass() != getClass()) {
            return false;
        }
        Road that = (Road) road;
        return from.equals(that.from) && to.equals(that.to) && length == that.length;
    }

    /**
     * Generates a hashcode based on the names of the cities and the length of the road. 
     * @return  The hashcode of the Road object.
     */
    @Override
    public int hashCode() { //Implementation acording to lecture notes "Slides-Uge11.pdf" p. 30.
        return 11*from.hashCode() + 13*to.hashCode() + 17*length;
    }
}
