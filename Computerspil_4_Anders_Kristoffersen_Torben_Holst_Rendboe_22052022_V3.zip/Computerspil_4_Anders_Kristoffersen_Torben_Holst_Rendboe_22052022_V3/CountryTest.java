
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Set;
import java.util.HashSet;

/**
 * The test class CountryTest.
 *
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-04-30 ("CG2 - Opgave 4") - Aproved by the test server
 */
public class CountryTest
{
    private Game game;
    private Country country1, country2;
    private City cityA, cityB, cityC, cityD, cityE, cityF, cityG;

    /**
     * Default constructor for test class CountryTest
     */
    public CountryTest() {

    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp() {
        // Create game object
        game = new Game(0);

        // Create countries
        country1 = new Country("Country 1");
        country1.setGame(game);

        country2 = new Country("Country 2");
        country2.setGame(game);

        // Create cities
        cityA = new City("City A", 80, country1);
        cityB = new City("City B", 60, country1);
        cityC = new City("City C", 40, country1);
        cityD = new City("City D", 100, country1);

        cityE = new City("City E", 50, country2);
        cityF = new City("City F", 90, country2);
        cityG = new City("City G", 70, country2);

        // Connect cities to countries
        country1.addCity(cityA);
        country1.addCity(cityB);
        country1.addCity(cityC);
        country1.addCity(cityD);

        country2.addCity(cityE);
        country2.addCity(cityF);
        country2.addCity(cityG);

        // Create roads
        country1.addRoads(cityA, cityB, 4);
        country1.addRoads(cityA, cityC, 3);
        country1.addRoads(cityA, cityD, 5);
        country1.addRoads(cityB, cityD, 2);
        country1.addRoads(cityC, cityD, 2);
        country1.addRoads(cityC, cityE, 4);
        country1.addRoads(cityD, cityF, 3);

        country2.addRoads(cityE, cityC, 4);
        country2.addRoads(cityE, cityF, 2);
        country2.addRoads(cityE, cityG, 5);
        country2.addRoads(cityF, cityD, 3);
        country2.addRoads(cityF, cityG, 6);
    }

    @Test
    public void constructor() {
        // setUp() creats 4 + 3 cities in two countries before this test
        assertEquals("Country 1", country1.getName());
        assertEquals(4, country1.getCities().size());   
        assertEquals("Country 2", country2.getName());
        assertEquals(3, country2.getCities().size());
    }

    // We don't have to test: getName, getGame, setGame

    @Test
    public void getCities() {
        assertEquals(4, country1.getCities().size());  // The number of cities suffice
        assertEquals(3, country2.getCities().size());
    }

    @Test
    public void getCity() {
        assertEquals(cityA, country1.getCity("City A"));  
        assertEquals(cityE, country2.getCity("City E"));
        assertEquals(null, country2.getCity("City B"));  // When the city doesn't excist in the country
    }

    @Test
    public void getRoads() {
        // setUp() adds roads to the cities
        assertEquals(3, country1.getRoads(cityA).size());  // The number of roads suffice
        assertEquals(3, country2.getRoads(cityE).size());
        assertTrue(country2.getRoads(cityB).isEmpty());    // When the city doesn't excist in the country
    }

    /* Se Slides-Uge12.pdf p. 
     */
    @Test
    public void reset() {
        // Teste at alle byer i country bliver reset
        cityA.changeValue(20);                          // To test reset() we need to change a city first
        assertEquals(100, cityA.getValue());
        country1.reset();
        assertEquals(80, cityA.getValue());

        cityE.changeValue(-50);
        country2.reset();
        assertEquals(50, cityE.getValue());

        cityE.arrive(); cityE.arrive(); cityE.arrive(); // Slides-Uge12.pdf p. 35  (Thee times zero bonus is unlikely)
        int valueE = cityE.getValue();                  // Remember value of cityE
        country1.reset();                               // No effect since cityE \in country1
        assertEquals(valueE, cityE.getValue());
    }

    @Test
    public void testToString() {
        assertEquals("Country 1", country1.toString());
        assertEquals("Country 2", country2.toString());  // Why doesn't test of one country test suffice?
    }

    @Test
    public void bonus() {
        for(int seed = 0; seed <= 100; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();
            int sumOfBonuses = 0;
            for(int k = 0; k < 100000; k++){
                int bonus = country1.bonus(cityA.getValue());
                assertTrue(0 <= bonus && bonus <= cityA.getValue());
                bonuses.add(bonus);
                sumOfBonuses += bonus;
            }
            int expectedSum = cityA.getInitialValue() * 100000 / 2;     // By multiplying before division we avoid loss of digits
            assertTrue(expectedSum * 0.99 <= sumOfBonuses && sumOfBonuses <= expectedSum * 1.01);
            assertEquals(cityA.getInitialValue() + 1, bonuses.size());
        }
        // bonus(1):
        for(int seed = 0; seed <= 100; seed++) {
            game.getRandom().setSeed(seed);          // Set seed
            Set<Integer> bonuses = new HashSet<>();
            int sumOfBonuses = 0;
            for(int k = 0; k < 100000; k++){
                int bonus = country1.bonus(1);
                assertTrue(0 <= bonus && bonus <= 1);
                bonuses.add(bonus);
                sumOfBonuses += bonus;
            }
            int expectedSum =  100000 / 2; 
            assertTrue(expectedSum * 0.99 <= sumOfBonuses && sumOfBonuses <= expectedSum * 1.01);
            assertEquals(2, bonuses.size());
        }
        // assertTrue(0 == country1.bonus(1) || 1 == country1.bonus(1));
        assertTrue(0 == country1.bonus(0));
    }

    @Test
    public void addCity() {
        assertEquals(4, country1.getCities().size());  // The number of cities suffice
        assertEquals(3, country2.getCities().size());
        country1.addCity(new City("City H", 120, country1));  // Create and add new city
        assertEquals(5, country1.getCities().size()); 
        assertEquals(3, country2.getCities().size());
    }

    @Test
    public void addRoads() {
        country1.addRoads(cityA, cityA, 1);                // Same city
        assertEquals(3, country1.getRoads(cityA).size());       // The number is the same as in the fixture (no change expected)
        assertEquals(2, country1.getRoads(cityB).size());       // The number is the same as in the fixture (no change expected)

        country1.addRoads(cityA, cityB, 1);                // Both cities in same country (lenght > 0)
        assertEquals(4, country1.getRoads(cityA).size());       // The number of roads from cityA grows from 3 (setUp) to 4
        assertEquals(3, country1.getRoads(cityB).size());       // The number of roads from cityB grows from 2 to 3 

        country1.addRoads(cityA, cityE, 10);               // City from in the country
        assertEquals(5, country1.getRoads(cityA).size());       // The number of roads from cityA grows from 4 to 5
        assertEquals(3, country2.getRoads(cityE).size());       // cityE not in country2

        country2.addRoads(cityA, cityE, 10);               // City to in country2
        assertEquals(5, country1.getRoads(cityA).size());       // The number is steady (no change expected)
        assertEquals(4, country2.getRoads(cityE).size());       // The number of roads from cityE grows from 3 to 4 

        country1.addRoads(cityE, cityF, 4);                // None of the cities in country 
        assertEquals(4, country2.getRoads(cityE).size());       // The number is steady (no change expected)
        assertEquals(3, country2.getRoads(cityF).size());       // The number is steady (no change expected)

        country1.addRoads(cityA, cityB, 0);                // length !> 0
        assertEquals(5, country1.getRoads(cityA).size());       // The number is steady (no change expected)
        assertEquals(3, country1.getRoads(cityB).size());       // The number is steady (no change expected)

        country1.addRoads(cityA, cityB, -3);                // length !> 0
        assertEquals(5, country1.getRoads(cityA).size());       // The number is steady (no change expected)
        assertEquals(3, country1.getRoads(cityB).size());       // The number is steady (no change expected)

    }

    @Test
    public void position() { 
        assertEquals(new Position(cityA, cityA, 0), country1.position(cityA));
        assertEquals(new Position(cityE, cityE, 0), country2.position(cityE));
    }

    @Test
    public void readyToTravel() {
        assertEquals(new Position(cityA, cityB, 4), country1.readyToTravel(cityA, cityB));
        assertEquals(country1.position(cityA), country1.readyToTravel(cityA, cityE));  // Different countries and no road
        assertEquals(country1.position(cityA), country1.readyToTravel(cityA, cityA));  // Same town
        assertEquals(country1.position(cityB), country1.readyToTravel(cityB, cityC));  // Same country and no road
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */ 
    @AfterEach
    public void tearDown() {
    }
}
