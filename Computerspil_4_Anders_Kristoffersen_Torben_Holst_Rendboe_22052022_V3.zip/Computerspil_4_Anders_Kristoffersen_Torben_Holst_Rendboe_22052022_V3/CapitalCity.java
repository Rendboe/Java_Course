
/**
 * The class CapitalCity models a capital in the computergame.
 * It is a subclass of BorderCity which in turn is a subclass of the class City
 *
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-05-08 (CG3-2) - Approved
 */
public class CapitalCity extends BorderCity
{
    /**
     * Creates a CapitalCity object passing parameters to field variables.
     * @param name      The name of the city
     * @param value     The value of the city
     * @param country   The country of the city
     */
    public CapitalCity(String name, int value, Country country){
        super(name, value, country); 
    }

    @Override
    public int arrive(Player p) { 
        int bonus = super.arrive(p);        // Subtracting toll when needed
        int money = p.getMoney();
        int expense = getCountry().getGame().getRandom().nextInt(money + bonus + 1);  // See comment in Brightspace
        super.changeValue(expense);
        return bonus - expense;
    }
}
