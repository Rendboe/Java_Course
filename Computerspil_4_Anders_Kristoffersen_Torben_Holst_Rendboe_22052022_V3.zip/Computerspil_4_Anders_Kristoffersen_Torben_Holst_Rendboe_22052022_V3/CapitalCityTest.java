
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class CapitalCityTest.
 *
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-05-11 (CG3-2) - Approved by testserver
 */
public class CapitalCityTest
{
    private Game game;
    private Country country1, country2;
    private City cityC, cityE, cityF;

    /**
     * Default constructor for test class CapitalCityTest
     */
    public CapitalCityTest()
    {
    }

    /**
     * Sets up the test fixture before every test case method.
     */
    @BeforeEach
    public void setUp() {
        // Create game object
        game = new Game(0);

        // Create countries
        country1 = new Country("Country 1");
        country1.setGame(game);                 // Remember to add this line

        country2 = new Country("Country 2");
        country2.setGame(game);                 // Remember to add this line

        // Create cities
        cityC = new BorderCity("City C", 40, country1);
        cityE = new CapitalCity("City E", 50, country2);
        cityF = new BorderCity("City F", 90, country2);

        // Connect cities to countries
        country1.addCity(cityC);
        country2.addCity(cityE);
        country2.addCity(cityF);

        // Create roads
        country1.addRoads(cityC, cityE, 4);
        country2.addRoads(cityE, cityC, 4);
        country2.addRoads(cityE, cityF, 2);
    }

    @Test
    public void constructor() {
    }

    @Test
    public void arrive() { 
        // Crossing a border
        for(int seed = 0; seed <= 1000; seed++) {
            Player player = new GUIPlayer(new Position(cityC, cityE, 0), 100);  // Not same country
            game.getRandom().setSeed(seed);          // Set seed
            int bonus = country2.bonus(50);          // cityE.getInitialValue() = 50
            int toll = country2.getGame().getSettings().getTollToBePaid();  // toll == 100 * 20 %
            int expense = game.getRandom().nextInt(100 + bonus - toll + 1);
            game.getRandom().setSeed(seed);          // Same seed as above
            assertEquals(bonus - toll - expense, cityE.arrive(player)); // bonus after paying toll
            assertEquals(50 - bonus + toll + expense, cityE.getValue());
            cityE.reset();                  
        }
        //Not crossing a border (no toll)
        for(int seed = 0; seed <= 1000; seed++) {
            Player player = new GUIPlayer(new Position(cityF, cityE, 0), 100);  // Same country
            game.getRandom().setSeed(seed);          // Set seed
            int bonus = country2.bonus(50);          // cityE.getInitialValue() = 50
            int expense = game.getRandom().nextInt(100 + bonus + 1);
            game.getRandom().setSeed(seed);          // Same seed as above
            assertEquals(bonus - expense, cityE.arrive(player));
            assertEquals(50 + expense - bonus, cityE.getValue());
            cityE.reset();                  
        }  
    }

    /**
     * Tears down the test fixture after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
