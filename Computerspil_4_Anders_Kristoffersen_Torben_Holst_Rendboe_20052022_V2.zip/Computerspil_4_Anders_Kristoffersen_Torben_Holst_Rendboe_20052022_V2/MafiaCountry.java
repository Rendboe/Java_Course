
/**
 * The classe MafiaCountry models a country with a risk for the player of being 
 * robbed of a part of the players money.
 * 
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-05-08 (CG3-3) - Approved by testserver
 */
public class MafiaCountry extends Country
{
    /**
     * Creates a MafiaCountry object.
     * @param name    The name of the country.
     */
    public MafiaCountry(String name){ 
        super(name); 
    }

    /**
     * The method returns a positive value if... and a negative otherwise.
     * @param value   The value of the city is the maximal bonus
     */
    @Override
    public int bonus(int value) {
        if(getGame().getRandom().nextInt(99) >= getGame().getSettings().getRisk()) {
            return super.bonus(value);
        } 
        return - getGame().getLoss();
    }
}
