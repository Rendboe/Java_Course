
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class PositionTest.
 *
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-04-16 ("CG2 - Opgave 2") - Godkendt af testserver
 */
public class PositionTest
{
    private Game game;
    private Country country1;
    private City cityA, cityB, cityC, cityD;
    private Position pos1, pos2;

    /**
     * Default constructor for test class PositionTest
     */
    public PositionTest() {

    }

    /**
     * Sets up the test fixture and will be called before every test case method.
     */
    @BeforeEach             
    public void setUp() {
        // Create game object
        game = new Game(0);

        // Create country
        country1 = new Country("Country 1");
        country1.setGame(game);

        // Create cities
        cityA = new City("City A", 80, country1);
        cityB = new City("City B", 60, country1);
        cityC = new City("City C", 40, country1);
        cityD = new City("City D", 100, country1);

        // Create positions
        pos1 = new Position(cityA, cityB, 4);
        pos2 = new Position(cityC, cityD, 2);
    }

    @Test
    public void constructor() {
        assertEquals(cityA, pos1.getFrom());
        assertEquals(cityB, pos1.getTo());
        assertEquals(4, pos1.getDistance());
        assertEquals(4, pos1.getTotal());
        assertEquals(cityC, pos2.getFrom());
        assertEquals(cityD, pos2.getTo());
        assertEquals(2, pos2.getDistance());
        assertEquals(2, pos2.getTotal());
    }

    @Test
    public void move() {
        // move() is executed three times on pos2 the return value and distance being asserted
        assertEquals(true,  pos2.move()); assertEquals(1, pos2.getDistance());
        assertEquals(true,  pos2.move()); assertEquals(0, pos2.getDistance()); // Has arrived
        assertEquals(false, pos2.move()); assertEquals(0, pos2.getDistance());
    }

    @Test
    public void turnAround() {
        // One step, turn and turn
        pos1.move();        
        pos1.turnAround();
        assertEquals(cityB, pos1.getFrom());
        assertEquals(cityA, pos1.getTo());
        assertEquals(1, pos1.getDistance());  // distance = 4 - 3;

        pos1.turnAround();
        assertEquals(cityA, pos1.getFrom());
        assertEquals(cityB, pos1.getTo());
        assertEquals(3, pos1.getDistance());   // distance = 4 - 1;

        // Turn and turn 
        pos2.turnAround();
        assertEquals(cityD, pos2.getFrom());
        assertEquals(cityC, pos2.getTo());
        assertEquals(0, pos2.getDistance());  // distance = 2 - 2;

        pos2.turnAround();
        assertEquals(cityC, pos2.getFrom());
        assertEquals(cityD, pos2.getTo());
        assertEquals(2, pos2.getDistance());  // distance = 2 - 0;
    }

    @Test
    public void hasArrived() {
        assertEquals(false, pos2.hasArrived());  // distance == 2
        pos2.move();
        assertEquals(false, pos2.hasArrived());  // distance == 1
        pos2.move();
        assertEquals(true, pos2.hasArrived());   // distance == 0
        pos2.move();
        assertEquals(true, pos2.hasArrived());   // distance == 0  still
    }

    @Test
    public void testToString() {
        assertEquals("City A (80) -> City B (60) : 4/4", pos1.toString());
        assertEquals("City C (40) -> City D (100) : 2/2", pos2.toString());
        pos2.move();
        assertEquals("City C (40) -> City D (100) : 1/2", pos2.toString());
        pos2.move();
        assertEquals("City C (40) -> City D (100) : 0/2", pos2.toString());
    }

    /**
     * Tears down the test fixture and will be called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
}
