
/**
 * The class Position models the where the player is on a road on the map.
 * @author Anders Kristoffersen & Torben Holst Rendboe
 * @version 2022-04-15 ("opgave 3")
 */
public class Position
{
    private City from, to;
    private int distance, total;

    /**
     * Creates a Position object with from, to and distance to the destination.
     * @param from      The city the player is moving from
     * @param to        The city the player is moving to
     * @param distance  The distance left for the player to move
     */
    public Position(City from, City to, int distance){
        this.from = from;
        this.to = to;
        this.distance = distance;
        this.total = distance;
    }

    /**
     * Gets the City the player is moving from.
     * @return    The City the player is moving from
     */
    public City getFrom(){
        return from;
    }

    /**
     * Gets the City the player is moving to.
     * @return The City the player is moving to
     */
    public City getTo(){
        return to;
    }

    /**
     * Gets the distance left for the player to move.
     * @return   The distance left for the player to move
     */
    public int getDistance(){
        return distance;
    }

    /**
     *  Gets the total distance between the two cities.
     *  @return The total distance between the two cities
     */
    public int getTotal(){
        return total;
    }

    /**
     * Reduces the distance by 1. 
     * @return      'true' if a move was carried out
     */
    public boolean move() {
        if(distance > 0){
            distance -= 1;
            return true;
        }
        return false;  
    }

    /**
     * The method swaps the two cities to and from and changes the distance traveled
     * so that it is measured form the new 'from' city.
     */
    public void turnAround(){
        City temp = to;
        to = from;
        from = temp;
        distance = total - distance;
        // Vender spillerens bevægelsesretning uden at spilleren flyttes        
    }

    /**
     * The method registers if the player has arrived or not.
     * @return    'true' if the player has arrives
     */
    public boolean hasArrived(){
        return distance == 0;
        // Returnerer (distance == 0)
    }

    /**
     * The method creates a string to display the status of the curent trip.
     * @return    A formattet string containing the fields (from -> to : distance/total).
     */
    @Override
    public String toString(){
        return from.toString() + " -> " + to.toString() + " : " + distance + "/" + total;
    }

    /**
     * Defines an equivalence relation of Position objects. 
     * @return 'true' if two Position objects have the same from, to, distance, and total 
     * and 'false' otherwise.
     */ 
    @Override 
    public boolean equals(Object position) {  //I mplementation acording to lecture notes "Slides-Uge11.pdf" p. 36.
        if(position == this) {
            return true;
        }
        if(position == null) {
            return false;
        }
        if(position.getClass() != getClass()) {
            return false;
        }
        Position that = (Position) position;
        return from.equals(that.from) && to.equals(that.to) && distance == that.distance && total == that.total;
    }

    /**
     * Generates a hashcode based on the from and to of the cities 
     * and distance and total  of the road. 
     * @return  The hashcode of the Road object.
     */
    @Override
    public int hashCode() { //Implementation acording to lecture notes "Slides-Uge11.pdf" p. 30.
        return 11*from.hashCode() + 13*to.hashCode() + 17*distance + 19*total;
    }
}
